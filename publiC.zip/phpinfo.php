<?php
echo exec('which php'); // Outputs the PHP CLI path